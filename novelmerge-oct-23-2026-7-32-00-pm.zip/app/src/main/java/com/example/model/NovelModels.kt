package com.example.model

import android.net.Uri

data class NovelWork(
    val id: String,
    val title: String,
    val description: String = "",
    val coverPath: String? = null,
    val chapterCount: Int = 0,
    val pageCount: Int = 0,
    val lastReadChapterId: String? = null,
    val lastReadPageIndex: Int = 0,
    val totalStorageBytes: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val lastReadAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
) {
    val progressPercent: Float
        get() = if (pageCount > 0 && lastReadPageIndex >= 0) {
            ((lastReadPageIndex + 1).toFloat() / pageCount.toFloat()).coerceIn(0f, 1f)
        } else 0f
}

data class Chapter(
    val id: String,
    val novelId: String,
    val chapterIndex: Int,
    val title: String,
    val pageCount: Int,
    val folderRelativePath: String,
    val thumbnailPath: String? = null,
    val isCompleted: Boolean = false
)

data class NovelPage(
    val chapterId: String,
    val pageNumber: Int,
    val globalPageNumber: Int = pageNumber,
    val chapterTitle: String = "",
    val chapterIndex: Int = 1,
    val absoluteFilePath: String,
    val fileName: String
)

data class PendingArchiveItem(
    val id: String,
    val uri: Uri,
    val fileName: String,
    val fileSizeBytes: Long,
    val detectedChapterIndex: Int,
    val customChapterTitle: String
)

enum class ReadingMode {
    WEBTOON,     // Continuous vertical scroll
    PAGED        // Horizontal page-by-page
}

enum class ReadingDirection {
    LEFT_TO_RIGHT,
    RIGHT_TO_LEFT // Traditional Manga style
}

enum class FitMode {
    FIT_WIDTH,
    FIT_SCREEN,
    ORIGINAL
}

enum class ReaderTheme(val bgHex: Long, val isDark: Boolean) {
    AMOLED_BLACK(0xFF000000, true),
    SLATE_DARK(0xFF16151F, true),
    SEPIA(0xFFFBF0D9, false),
    LIGHT(0xFFF8F9FA, false)
}

data class ReaderSettings(
    val readingMode: ReadingMode = ReadingMode.WEBTOON,
    val readingDirection: ReadingDirection = ReadingDirection.LEFT_TO_RIGHT,
    val fitMode: FitMode = FitMode.FIT_WIDTH,
    val theme: ReaderTheme = ReaderTheme.AMOLED_BLACK
)
