package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Divine Solar Obsidian & Bronze Dark Backgrounds
val DarkBackground = Color(0xFF0C0A09)
val DarkSurface = Color(0xFF18130E)
val DarkSurfaceElevated = Color(0xFF261D14)
val DarkSurfaceBorder = Color(0xFF45331E)

// Divine Celestial Rule Solar Colors (İlahi Altın Sarısı & Turuncu)
val NovelPrimary = Color(0xFFF59E0B)         // Divine Solar Gold
val NovelPrimaryLight = Color(0xFFFBBF24)    // Celestial Radiant Gold
val NovelSecondary = Color(0xFFEA580C)       // Divine Solar Flame Orange
val NovelSecondaryLight = Color(0xFFFB923C)  // Warm Sunburst Orange
val NovelAccentGold = Color(0xFFFFD54F)      // Imperial Sacred Gold Highlight
val NovelAccentOrange = Color(0xFFF97316)    // Vibrant Solar Orange
val NovelAccentCyan = Color(0xFF38BDF8)

// Divine Sun Engraving & Halo Colors
val DivineSunGlow = Color(0x33F59E0B)        // Subtle Golden Solar Aura
val DivineSunRays = Color(0x2EFBBF24)        // Delicate Solar Rays Engraving
val DivineSunCore = Color(0x40EA580C)        // Sacred Solar Flame Heart

val TextPrimaryDark = Color(0xFFFFFBF0)      // Warm Golden-tinted White
val TextSecondaryDark = Color(0xFFD4C7B5)    // Parchment Light Bronze
val TextMuted = Color(0xFF8F7E6B)            // Muted Bronze

val LightBackground = Color(0xFFFFFDF8)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFFAF3E6)
val LightPrimary = Color(0xFFD97706)
