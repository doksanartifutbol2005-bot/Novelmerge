package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NovelAccentGold
import com.example.ui.theme.NovelPrimary
import com.example.ui.theme.NovelPrimaryLight
import com.example.ui.theme.NovelSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlinx.coroutines.delay
import kotlin.math.sin

/**
 * Opening celestial splash and loading screen featuring the user's magnificent Divine Sun Knight
 * with ambient solar pulsing aura, rising golden embers/sparks, sweeping light gleam,
 * and illuminated progress transition into the library.
 */
@Composable
fun DivineAngelSplashScreen(
    onFinished: () -> Unit
) {
    var progress by remember { mutableFloatStateOf(0.08f) }
    var statusText by remember { mutableStateOf("İlahi Güneşin Hükmü Uyanıyor...") }

    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(550, easing = FastOutSlowInEasing),
        label = "splashProgress"
    )

    // Dynamic loading phases
    LaunchedEffect(Unit) {
        delay(400)
        progress = 0.35f
        statusText = "Kutsal Ciltler ve Sayfalar Çözümleniyor..."
        delay(700)
        progress = 0.72f
        statusText = "Güneş Işığı Arşivi Hazırlıyor..."
        delay(650)
        progress = 0.96f
        statusText = "İlahi Kütüphane Açılıyor..."
        delay(500)
        progress = 1.0f
        delay(250)
        onFinished()
    }

    val infiniteTransition = rememberInfiniteTransition(label = "DivineScreenEffects")

    // Slow cinematic breathing zoom on the artwork
    val heroScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(7000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heroScale"
    )

    // Ambient Solar Halo Glow pulsing
    val sunPulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sunPulse"
    )

    // Rising sparks and particles animation phase
    val particlePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "particlePhase"
    )

    // Sword light sheen flash
    val swordGleam by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "swordGleam"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .clickable { onFinished() }
            .testTag("divine_angel_splash_screen")
    ) {
        // 1. Full-screen Hero Art (The Divine Sun Warrior) with subtle parallax breathing
        Image(
            painter = painterResource(id = R.drawable.img_divine_sun_knight),
            contentDescription = "İlahi Güneş Savaşçısı",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = heroScale
                    scaleY = heroScale
                }
        )

        // 2. Ambient Canvas Effects: Solar Core Halo & Rising Golden Sparks
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Solar crown radiant halo glow (located around the sun behind warrior's head)
            val sunCenter = Offset(w * 0.49f, h * 0.22f)
            val sunRadius = (w * 0.48f) * sunPulse

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        NovelAccentGold.copy(alpha = 0.38f),
                        NovelPrimary.copy(alpha = 0.22f),
                        NovelSecondary.copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    center = sunCenter,
                    radius = sunRadius
                ),
                center = sunCenter,
                radius = sunRadius
            )

            // Rising Golden Sparks & Embers (24 particles rising from earth into the sun)
            val sparkCount = 24
            for (i in 0 until sparkCount) {
                val seed = (i * 37.13f) % 1f
                val startX = w * ((i * 43.7f) % 1f)
                val speed = 0.6f + (i % 5) * 0.15f
                val progressOffset = (particlePhase * speed + seed) % 1f

                val sparkY = h * (1.05f - (progressOffset * 1.1f))
                val waveX = sin((particlePhase * Math.PI * 4 + i).toDouble()).toFloat() * (16f * seed)
                val currentX = (startX + waveX).coerceIn(0f, w)

                val sparkAlpha = (sin(progressOffset.toDouble() * Math.PI).toFloat()).coerceIn(0f, 1f) * 0.85f
                val sparkRadius = 1.8f + (i % 3) * 1.4f

                drawCircle(
                    color = if (i % 2 == 0) NovelAccentGold.copy(alpha = sparkAlpha) else NovelPrimaryLight.copy(alpha = sparkAlpha),
                    radius = sparkRadius,
                    center = Offset(currentX, sparkY)
                )
            }

            // Sword light sheen flash effect
            if (swordGleam in 0.15f..0.45f) {
                val sheenAlpha = (sin(((swordGleam - 0.15f) / 0.30f) * Math.PI).toFloat()).coerceIn(0f, 1f) * 0.55f
                drawLine(
                    brush = Brush.linearGradient(
                        colors = listOf(Color.Transparent, Color.White, NovelAccentGold, Color.Transparent),
                        start = Offset(w * 0.2f, h * 0.32f),
                        end = Offset(w * 0.85f, h * 0.25f)
                    ),
                    start = Offset(w * 0.2f, h * 0.32f),
                    end = Offset(w * 0.85f, h * 0.25f),
                    strokeWidth = 6f,
                    alpha = sheenAlpha
                )
            }
        }

        // 3. Cinematic Gradients for Crisp Legibility
        // Top vignette (status bar)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .align(Alignment.TopCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xD90C0A09), Color.Transparent)
                    )
                )
        )

        // Bottom cinematic fade for titles & progress
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(340.dp)
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Transparent,
                            Color(0x990C0A09),
                            Color(0xF20C0A09),
                            Color(0xFF0C0A09)
                        )
                    )
                )
        )

        // 4. Foreground UI: Header Badge, Title, Progress & Status
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Bottom,
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 20.dp)
        ) {
            // Radiant Divine Crest Badge
            Surface(
                color = NovelPrimary.copy(alpha = 0.25f),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NovelAccentGold.copy(alpha = 0.6f)),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                ) {
                    Icon(
                        Icons.Default.Bolt,
                        contentDescription = null,
                        tint = NovelAccentGold,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "GÜNEŞİN KUTSAL IŞIĞI",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NovelAccentGold,
                        letterSpacing = 2.sp
                    )
                }
            }

            // Divine Decree Epic Title
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = NovelAccentGold,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "İLAHİ KURAL",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 4.sp,
                    color = TextPrimaryDark,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.width(10.dp))
                Icon(
                    Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = NovelAccentGold,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Subtitle
            Text(
                text = "Kutsal Görsel Roman & Webtoon Kitaplığı",
                fontSize = 13.sp,
                color = NovelAccentGold,
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Glowing Solar Progress Bar Card
            Surface(
                color = Color(0x6618130E),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NovelPrimary.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth(0.92f)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Shimmering Progress Bar
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp)
                            .clip(CircleShape),
                        color = NovelPrimary,
                        trackColor = DarkSurfaceElevated
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = statusText,
                            fontSize = 12.sp,
                            color = TextSecondaryDark,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "${(animatedProgress * 100).toInt()}%",
                            fontSize = 12.sp,
                            color = NovelAccentGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Touch anywhere / Skip Affordance
            TextButton(
                onClick = onFinished,
                colors = ButtonDefaults.textButtonColors(contentColor = TextMuted),
                modifier = Modifier.testTag("btn_skip_splash")
            ) {
                Text(
                    text = "Dokunarak Doğrudan Başla →",
                    fontSize = 12.sp,
                    color = TextMuted
                )
            }
        }
    }
}
