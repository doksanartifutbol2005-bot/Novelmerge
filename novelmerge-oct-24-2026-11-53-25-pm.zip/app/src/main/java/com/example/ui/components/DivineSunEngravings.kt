package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DivineSunCore
import com.example.ui.theme.DivineSunGlow
import com.example.ui.theme.DivineSunRays
import com.example.ui.theme.NovelAccentGold
import com.example.ui.theme.NovelPrimary
import com.example.ui.theme.NovelSecondary
import kotlin.math.cos
import kotlin.math.sin

/**
 * A majestic procedural abstract divine sun engraving background.
 * Renders celestial solar mandala circles, radiant sun rays, sacred geometry rings,
 * and a warm solar halo aura.
 */
@Composable
fun DivineSunBackground(
    modifier: Modifier = Modifier,
    alpha: Float = 0.85f,
    sunCenterBiasY: Float = 0.28f, // Places the divine sun in upper third like a rising imperial sun
    content: @Composable () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "DivineSunRotation")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(120000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "solarRotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "solarPulse"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Divine Sun Engraving Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width * 0.5f, size.height * sunCenterBiasY)
            val baseRadius = (size.width * 0.42f) * pulseScale

            // 1. Celestial Solar Halo Radial Gradients
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        NovelSecondary.copy(alpha = 0.20f * alpha),
                        NovelPrimary.copy(alpha = 0.12f * alpha),
                        Color(0xFFFBBF24).copy(alpha = 0.05f * alpha),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 2.2f
                ),
                radius = baseRadius * 2.2f,
                center = center
            )

            // Inner intense divine core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        NovelAccentGold.copy(alpha = 0.28f * alpha),
                        NovelPrimary.copy(alpha = 0.18f * alpha),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 0.75f
                ),
                radius = baseRadius * 0.75f,
                center = center
            )

            // 2. Slow Rotating Sacred Sun Rays & Mandala Engravings
            rotate(rotationAngle, pivot = center) {
                // Concentric celestial orbit rings with fine filigree
                drawCircle(
                    color = DivineSunRays.copy(alpha = 0.45f * alpha),
                    radius = baseRadius * 0.55f,
                    center = center,
                    style = Stroke(width = 1.2f)
                )

                drawCircle(
                    color = NovelPrimary.copy(alpha = 0.35f * alpha),
                    radius = baseRadius * 0.72f,
                    center = center,
                    style = Stroke(
                        width = 1.5f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                    )
                )

                drawCircle(
                    color = DivineSunRays.copy(alpha = 0.5f * alpha),
                    radius = baseRadius * 0.95f,
                    center = center,
                    style = Stroke(width = 1.8f)
                )

                drawCircle(
                    color = NovelAccentGold.copy(alpha = 0.3f * alpha),
                    radius = baseRadius * 1.15f,
                    center = center,
                    style = Stroke(
                        width = 1.2f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 12f), 0f)
                    )
                )

                drawCircle(
                    color = DivineSunRays.copy(alpha = 0.25f * alpha),
                    radius = baseRadius * 1.45f,
                    center = center,
                    style = Stroke(
                        width = 1.0f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 15f), 0f)
                    )
                )

                // 24 Radiant Divine Sun Rays (Alternating primary and secondary solar flares)
                val rayCount = 24
                val angleStep = (2 * Math.PI / rayCount).toFloat()

                for (i in 0 until rayCount) {
                    val angle = i * angleStep
                    val isMajorRay = i % 2 == 0
                    val isCardinal = i % 6 == 0

                    val rayInnerRadius = baseRadius * 0.96f
                    val rayOuterRadius = when {
                        isCardinal -> baseRadius * 1.75f
                        isMajorRay -> baseRadius * 1.45f
                        else -> baseRadius * 1.25f
                    }

                    val cosA = cos(angle.toDouble()).toFloat()
                    val sinA = sin(angle.toDouble()).toFloat()

                    val start = Offset(
                        center.x + cosA * rayInnerRadius,
                        center.y + sinA * rayInnerRadius
                    )
                    val end = Offset(
                        center.x + cosA * rayOuterRadius,
                        center.y + sinA * rayOuterRadius
                    )

                    val rayColor = if (isCardinal) {
                        NovelAccentGold.copy(alpha = 0.55f * alpha)
                    } else if (isMajorRay) {
                        NovelPrimary.copy(alpha = 0.40f * alpha)
                    } else {
                        DivineSunRays.copy(alpha = 0.30f * alpha)
                    }

                    val strokeW = if (isCardinal) 2.2f else if (isMajorRay) 1.5f else 1.0f

                    drawLine(
                        color = rayColor,
                        start = start,
                        end = end,
                        strokeWidth = strokeW
                    )

                    // Solar ray tip diamond or decorative dot
                    if (isMajorRay) {
                        drawCircle(
                            color = NovelAccentGold.copy(alpha = 0.6f * alpha),
                            radius = if (isCardinal) 3.5f else 2.2f,
                            center = end
                        )
                    }
                }

                // 8-Point Sacred Divine Sun Star in the core
                val starPath = Path()
                val starPoints = 8
                val outerR = baseRadius * 0.45f
                val innerR = baseRadius * 0.22f
                val starStep = (Math.PI / starPoints).toFloat()

                for (p in 0 until (starPoints * 2)) {
                    val currentR = if (p % 2 == 0) outerR else innerR
                    val pAngle = p * starStep
                    val px = center.x + (cos(pAngle.toDouble()) * currentR).toFloat()
                    val py = center.y + (sin(pAngle.toDouble()) * currentR).toFloat()
                    if (p == 0) starPath.moveTo(px, py) else starPath.lineTo(px, py)
                }
                starPath.close()

                drawPath(
                    path = starPath,
                    color = NovelAccentGold.copy(alpha = 0.22f * alpha),
                    style = Stroke(width = 1.8f)
                )
            }

            // Reverse subtle secondary sun wheel (counter-rotating for sacred depth)
            rotate(-rotationAngle * 0.6f, pivot = center) {
                val flareCount = 12
                val flareStep = (2 * Math.PI / flareCount).toFloat()
                for (j in 0 until flareCount) {
                    val angle = j * flareStep
                    val startR = baseRadius * 0.73f
                    val flareR = baseRadius * 0.88f
                    val cosA = cos(angle.toDouble()).toFloat()
                    val sinA = sin(angle.toDouble()).toFloat()
                    drawCircle(
                        color = NovelSecondary.copy(alpha = 0.4f * alpha),
                        radius = 2.5f,
                        center = Offset(center.x + cosA * flareR, center.y + sinA * flareR)
                    )
                }
            }
        }

        // Screen content rendered atop divine backdrop
        content()
    }
}
