package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import com.example.ui.components.DivineSunBackground
import com.example.ui.components.DivineAngelFigure
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Merge
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PendingArchiveItem
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NovelAccentGold
import com.example.ui.theme.NovelPrimary
import com.example.ui.theme.NovelSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.viewmodel.AppScreen
import com.example.viewmodel.NovelViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MergeStudioScreen(viewModel: NovelViewModel) {
    val context = LocalContext.current
    val pendingItems by viewModel.pendingArchives.collectAsState()
    val suggestedTitle by viewModel.suggestedNovelTitle.collectAsState()
    var novelTitleInput by remember(suggestedTitle) { mutableStateOf(suggestedTitle) }
    var novelDescInput by remember { mutableStateOf("") }

    val isMerging by viewModel.isMerging.collectAsState()
    val mergeProgress by viewModel.mergeProgress.collectAsState()
    val mergeStatusText by viewModel.mergeStatusText.collectAsState()

    BackHandler {
        if (!isMerging) {
            viewModel.navigateTo(AppScreen.LIBRARY)
        }
    }

    // Multi-file picker for archives (.rar, .zip, .cbz)
    val archivePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (!uris.isNullOrEmpty()) {
            val filePairs = uris.map { uri ->
                var displayName = "chapter_${System.currentTimeMillis()}.zip"
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1) {
                            displayName = cursor.getString(nameIndex) ?: displayName
                        }
                    }
                }
                Pair(uri, displayName)
            }
            viewModel.addArchiveUris(filePairs)
        }
    }

    DivineSunBackground(
        alpha = 0.85f,
        sunCenterBiasY = 0.25f
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DarkSurface.copy(alpha = 0.85f),
                        titleContentColor = TextPrimaryDark
                    ),
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppScreen.LIBRARY) },
                        enabled = !isMerging,
                        modifier = Modifier.testTag("btn_back_merge_studio")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Geri",
                            tint = TextPrimaryDark
                        )
                    }
                },
                title = {
                    Column {
                        Text(
                            text = "Chapter Birleştirme Stüdyosu",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Text(
                            text = "WinRAR & ZIP Bölümlerini Tek Parçaya Dönüştür",
                            fontSize = 11.sp,
                            color = TextSecondaryDark
                        )
                    }
                },
                actions = {
                    if (pendingItems.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.clearPendingArchives() },
                            enabled = !isMerging,
                            modifier = Modifier.testTag("btn_clear_queue")
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Kuyruğu Temizle", tint = Color(0xFFEF4444))
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (pendingItems.isNotEmpty()) {
                Surface(
                    color = DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${pendingItems.size} Chapter Seçildi",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimaryDark
                            )
                            Text(
                                text = "Otomatik Bölüm Sıralı",
                                fontSize = 12.sp,
                                color = NovelAccentGold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                viewModel.startBatchMerge(novelTitleInput, novelDescInput)
                            },
                            enabled = !isMerging && pendingItems.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NovelPrimary,
                                disabledContainerColor = DarkSurfaceElevated
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("btn_start_merge")
                        ) {
                            Icon(Icons.Default.Merge, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Tümünü Tek Parça Görsel Romana Dönüştür",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Explanatory Banner
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(NovelPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = NovelPrimary)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Nasıl Çalışır?",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Görsel romanınıza ait tüm WinRAR (.rar) veya .zip chapter dosyalarını toplu olarak seçin. Uygulama bölüm numaralarını (Bölüm 1, 2, ... 10) otomatik olarak sıralar, ayıklar ve tek bir görsel roman haline getirir.",
                                fontSize = 12.sp,
                                color = TextSecondaryDark,
                                lineHeight = 17.sp
                            )
                        }
                    }
                }
            }

            // Big Upload CTA Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(enabled = !isMerging) {
                            archivePickerLauncher.launch(
                                arrayOf(
                                    "*/*",
                                    "application/zip",
                                    "application/x-zip-compressed",
                                    "application/x-rar-compressed",
                                    "application/vnd.rar",
                                    "application/octet-stream"
                                )
                            )
                        }
                        .border(
                            2.dp,
                            Brush.linearGradient(listOf(NovelPrimary, NovelSecondary)),
                            RoundedCornerShape(16.dp)
                        )
                        .testTag("card_upload_archives"),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(NovelPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.FolderZip,
                                contentDescription = null,
                                tint = NovelPrimary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = if (pendingItems.isEmpty()) "WinRAR & ZIP Chapter Dosyalarını Seçin" else "Daha Fazla Chapter Dosyası Ekle",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Tek seferde 10, 20 veya 50+ dosya seçebilirsiniz",
                            fontSize = 12.sp,
                            color = TextSecondaryDark
                        )
                    }
                }
            }

            // Series Details Input Form (shown once files are added)
            if (pendingItems.isNotEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Görsel Roman Bilgileri",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = novelTitleInput,
                                onValueChange = { novelTitleInput = it },
                                label = { Text("Roman / Seri Adı") },
                                placeholder = { Text("Örn: Steins;Gate, Solo Leveling...") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NovelPrimary,
                                    unfocusedBorderColor = DarkSurfaceBorder,
                                    focusedLabelColor = NovelPrimary,
                                    unfocusedLabelColor = TextSecondaryDark,
                                    focusedTextColor = TextPrimaryDark,
                                    unfocusedTextColor = TextPrimaryDark
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_novel_title")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = novelDescInput,
                                onValueChange = { novelDescInput = it },
                                label = { Text("Açıklama veya Not (İsteğe Bağlı)") },
                                placeholder = { Text("Örn: Cilt 1-3 toplu birleştirilmiş arşiv") },
                                maxLines = 2,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NovelPrimary,
                                    unfocusedBorderColor = DarkSurfaceBorder,
                                    focusedLabelColor = NovelPrimary,
                                    unfocusedLabelColor = TextSecondaryDark,
                                    focusedTextColor = TextPrimaryDark,
                                    unfocusedTextColor = TextPrimaryDark
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_novel_desc")
                            )
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Bölüm Sıralaması (${pendingItems.size})",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Text(
                            text = "Yukarı/Aşağı ile Sıralayın",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }

                itemsIndexed(pendingItems, key = { _, item -> item.id }) { index, item ->
                    PendingChapterRowItem(
                        item = item,
                        orderNumber = index + 1,
                        canMoveUp = index > 0,
                        canMoveDown = index < pendingItems.size - 1,
                        onMoveUp = { viewModel.movePendingItemUp(index) },
                        onMoveDown = { viewModel.movePendingItemDown(index) },
                        onTitleChange = { newTitle -> viewModel.updatePendingItemTitle(item.id, newTitle) },
                        onRemove = { viewModel.removePendingItem(item.id) }
                    )
                }
            }
        }
    }

    // Merge Progress Dialog
    if (isMerging) {
        AlertDialog(
            onDismissRequest = { /* prevent dismiss while merging */ },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 3.dp,
                        color = NovelPrimary
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Tek Parçaya Dönüştürülüyor...",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    DivineAngelFigure(
                        size = 140.dp,
                        showAura = true,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    Text(
                        text = mergeStatusText,
                        fontSize = 13.sp,
                        color = TextSecondaryDark,
                        lineHeight = 18.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    LinearProgressIndicator(
                        progress = { mergeProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = NovelPrimary,
                        trackColor = DarkSurfaceBorder
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "${(mergeProgress * 100).toInt()}% Tamamlandı",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NovelAccentGold,
                        modifier = Modifier.align(Alignment.End)
                    )
                }
            },
            confirmButton = {},
            containerColor = DarkSurfaceElevated,
            shape = RoundedCornerShape(16.dp)
        )
    }
}
}

@Composable
fun PendingChapterRowItem(
    item: PendingArchiveItem,
    orderNumber: Int,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onTitleChange: (String) -> Unit,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(12.dp))
            .testTag("pending_item_$orderNumber"),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Order number badge
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(NovelPrimary.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "#$orderNumber",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = NovelPrimary
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details and editable title
            Column(modifier = Modifier.weight(1f)) {
                OutlinedTextField(
                    value = item.customChapterTitle,
                    onValueChange = onTitleChange,
                    singleLine = true,
                    label = { Text("Bölüm Başlığı", fontSize = 10.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovelPrimary,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = item.fileName,
                    fontSize = 10.sp,
                    color = TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Reordering up/down buttons
            Column {
                IconButton(
                    onClick = onMoveUp,
                    enabled = canMoveUp,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        Icons.Default.ArrowUpward,
                        contentDescription = "Yukarı Taşı",
                        tint = if (canMoveUp) TextPrimaryDark else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(
                    onClick = onMoveDown,
                    enabled = canMoveDown,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        Icons.Default.ArrowDownward,
                        contentDescription = "Aşağı Taşı",
                        tint = if (canMoveDown) TextPrimaryDark else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Remove button
            IconButton(
                onClick = onRemove,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    Icons.Default.Close,
                    contentDescription = "Kaldır",
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
