package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.NovelAccentGold
import com.example.ui.theme.NovelPrimary
import com.example.ui.theme.NovelPrimaryLight
import com.example.ui.theme.NovelSecondary
import kotlin.math.cos
import kotlin.math.sin

/**
 * An exquisite animated illustration of a serene celestial angel reading an open sacred book of light,
 * featuring breathing feathered wings, radiant divine solar halo, and floating golden feathers and light beams.
 */
@Composable
fun DivineAngelFigure(
    modifier: Modifier = Modifier,
    size: Dp = 260.dp,
    showAura: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "DivineAngelAnim")

    // Wing breathing motion
    val wingSpread by infiniteTransition.animateFloat(
        initialValue = -3f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wingSpread"
    )

    // Halo pulse and golden glow
    val haloPulse by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "haloPulse"
    )

    // Light ray sparkle phase
    val rayPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rayPhase"
    )

    // Floating drift
    val floatOffset by infiniteTransition.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "floatOffset"
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasW = this.size.width
            val canvasH = this.size.height
            val scale = canvasW / 300f
            val cx = canvasW * 0.5f
            val cy = (canvasH * 0.52f) + (floatOffset * scale)

            // 1. Divine Ambient Halo Aura
            if (showAura) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            NovelAccentGold.copy(alpha = 0.35f * haloPulse),
                            NovelPrimary.copy(alpha = 0.18f),
                            Color(0xFFEA580C).copy(alpha = 0.06f),
                            Color.Transparent
                        ),
                        center = Offset(cx, cy - (40f * scale)),
                        radius = 120f * scale * haloPulse
                    ),
                    radius = 120f * scale * haloPulse,
                    center = Offset(cx, cy - (40f * scale))
                )
            }

            // 2. Solar Halo Ring above Angel's head
            val haloCenter = Offset(cx, cy - (68f * scale))
            drawOval(
                brush = Brush.horizontalGradient(
                    listOf(NovelPrimaryLight, NovelAccentGold, NovelPrimaryLight)
                ),
                topLeft = Offset(haloCenter.x - (38f * scale), haloCenter.y - (14f * scale * haloPulse)),
                size = Size(76f * scale, 28f * scale * haloPulse),
                style = Stroke(width = 3.5f * scale, cap = StrokeCap.Round)
            )

            // 3. Seraph Wings (Left & Right) with breathing rotation
            // Left Wing
            rotate(degrees = wingSpread, pivot = Offset(cx - (20f * scale), cy - (10f * scale))) {
                drawAngelWing(
                    cx = cx,
                    cy = cy,
                    scale = scale,
                    isLeft = true
                )
            }

            // Right Wing
            rotate(degrees = -wingSpread, pivot = Offset(cx + (20f * scale), cy - (10f * scale))) {
                drawAngelWing(
                    cx = cx,
                    cy = cy,
                    scale = scale,
                    isLeft = false
                )
            }

            // 4. Angel Divine Robe & Body
            val robePath = Path().apply {
                moveTo(cx - (18f * scale), cy - (15f * scale))
                lineTo(cx + (18f * scale), cy - (15f * scale))
                lineTo(cx + (35f * scale), cy + (75f * scale))
                quadraticBezierTo(
                    cx, cy + (85f * scale),
                    cx - (35f * scale), cy + (75f * scale)
                )
                close()
            }
            drawPath(
                path = robePath,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFFFFFBF0), Color(0xFFFDE68A), Color(0xFFF59E0B)),
                    startY = cy - (15f * scale),
                    endY = cy + (85f * scale)
                )
            )

            // Golden Stole / Sash down robe
            val stolePath = Path().apply {
                moveTo(cx - (6f * scale), cy - (15f * scale))
                lineTo(cx + (6f * scale), cy - (15f * scale))
                lineTo(cx + (8f * scale), cy + (78f * scale))
                lineTo(cx - (8f * scale), cy + (78f * scale))
                close()
            }
            drawPath(stolePath, color = NovelSecondary.copy(alpha = 0.85f))

            // 5. Angel Head & Hair
            val headCenter = Offset(cx, cy - (38f * scale))
            drawCircle(
                color = Color(0xFFFFFBF0),
                radius = 18f * scale,
                center = headCenter
            )

            // Flowing Golden Locks of Hair
            val hairPath = Path().apply {
                moveTo(cx, cy - (58f * scale))
                cubicTo(
                    cx - (22f * scale), cy - (58f * scale),
                    cx - (26f * scale), cy - (42f * scale),
                    cx - (24f * scale), cy - (20f * scale)
                )
                cubicTo(
                    cx - (18f * scale), cy - (32f * scale),
                    cx - (12f * scale), cy - (38f * scale),
                    cx, cy - (42f * scale)
                )
                cubicTo(
                    cx + (12f * scale), cy - (38f * scale),
                    cx + (18f * scale), cy - (32f * scale),
                    cx + (24f * scale), cy - (20f * scale)
                )
                cubicTo(
                    cx + (26f * scale), cy - (42f * scale),
                    cx + (22f * scale), cy - (58f * scale),
                    cx, cy - (58f * scale)
                )
                close()
            }
            drawPath(
                path = hairPath,
                brush = Brush.verticalGradient(
                    listOf(NovelAccentGold, NovelPrimary)
                )
            )

            // Serene peaceful closed eyes (meditating / reading)
            drawLine(
                color = Color(0xFF8B5E34),
                start = Offset(cx - (8f * scale), cy - (36f * scale)),
                end = Offset(cx - (3f * scale), cy - (35f * scale)),
                strokeWidth = 1.5f * scale,
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color(0xFF8B5E34),
                start = Offset(cx + (3f * scale), cy - (35f * scale)),
                end = Offset(cx + (8f * scale), cy - (36f * scale)),
                strokeWidth = 1.5f * scale,
                cap = StrokeCap.Round
            )

            // 6. Open Sacred Book of Light in Angel's Hands
            val bookY = cy + (12f * scale)

            // Left Page
            val leftPage = Path().apply {
                moveTo(cx, bookY + (4f * scale))
                lineTo(cx - (52f * scale), bookY - (14f * scale))
                cubicTo(
                    cx - (54f * scale), bookY + (10f * scale),
                    cx - (53f * scale), bookY + (24f * scale),
                    cx - (50f * scale), bookY + (32f * scale)
                )
                lineTo(cx, bookY + (46f * scale))
                close()
            }
            drawPath(
                path = leftPage,
                brush = Brush.linearGradient(
                    colors = listOf(Color.White, Color(0xFFFEF3C7)),
                    start = Offset(cx, bookY),
                    end = Offset(cx - (52f * scale), bookY)
                )
            )
            drawPath(leftPage, color = NovelPrimary, style = Stroke(width = 2.2f * scale))

            // Right Page
            val rightPage = Path().apply {
                moveTo(cx, bookY + (4f * scale))
                lineTo(cx + (52f * scale), bookY - (14f * scale))
                cubicTo(
                    cx + (54f * scale), bookY + (10f * scale),
                    cx + (53f * scale), bookY + (24f * scale),
                    cx + (50f * scale), bookY + (32f * scale)
                )
                lineTo(cx, bookY + (46f * scale))
                close()
            }
            drawPath(
                path = rightPage,
                brush = Brush.linearGradient(
                    colors = listOf(Color.White, Color(0xFFFEF3C7)),
                    start = Offset(cx, bookY),
                    end = Offset(cx + (52f * scale), bookY)
                )
            )
            drawPath(rightPage, color = NovelPrimary, style = Stroke(width = 2.2f * scale))

            // Sacred golden spine
            drawLine(
                color = NovelSecondary,
                start = Offset(cx, bookY + (2f * scale)),
                end = Offset(cx, bookY + (48f * scale)),
                strokeWidth = 3f * scale
            )

            // Sacred Book Scripture Lines (mini text lines)
            for (lineIdx in 0..2) {
                val lineOffset = (lineIdx * 9f + 6f) * scale
                drawLine(
                    color = NovelPrimary.copy(alpha = 0.5f),
                    start = Offset(cx - (42f * scale), bookY - (4f * scale) + lineOffset),
                    end = Offset(cx - (10f * scale), bookY + (10f * scale) + lineOffset),
                    strokeWidth = 1.4f * scale,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = NovelPrimary.copy(alpha = 0.5f),
                    start = Offset(cx + (10f * scale), bookY + (10f * scale) + lineOffset),
                    end = Offset(cx + (42f * scale), bookY - (4f * scale) + lineOffset),
                    strokeWidth = 1.4f * scale,
                    cap = StrokeCap.Round
                )
            }

            // 7. Beams of Divine Light Radiating from the Open Book Upwards toward Angel
            val rayCount = 5
            for (r in 0 until rayCount) {
                val angleOffset = ((r - 2) * 18f)
                val rayRad = Math.toRadians((angleOffset - 90).toDouble())
                val rayLen = (35f + (r % 2) * 15f) * scale * haloPulse
                val rx = cx + (cos(rayRad) * rayLen).toFloat()
                val ry = (bookY + 15f * scale) + (sin(rayRad) * rayLen).toFloat()

                drawLine(
                    brush = Brush.linearGradient(
                        listOf(NovelAccentGold, Color.Transparent),
                        start = Offset(cx, bookY + 15f * scale),
                        end = Offset(rx, ry)
                    ),
                    start = Offset(cx, bookY + 15f * scale),
                    end = Offset(rx, ry),
                    strokeWidth = 2.5f * scale,
                    cap = StrokeCap.Round
                )
            }

            // 8. Celestial Floating Sparkles / Particles
            val sparkles = listOf(
                Triple(-65f, -25f, 3.5f),
                Triple(68f, -22f, 3.8f),
                Triple(-38f, -75f, 2.5f),
                Triple(42f, -70f, 3.0f),
                Triple(-85f, 40f, 2.2f),
                Triple(82f, 45f, 2.8f)
            )
            sparkles.forEachIndexed { i, (sx, sy, rad) ->
                val dynamicAlpha = ((sin(Math.PI * 2 * (rayPhase + i * 0.2f)).toFloat() + 1f) / 2f).coerceIn(0.2f, 1f)
                drawCircle(
                    color = NovelAccentGold.copy(alpha = dynamicAlpha),
                    radius = rad * scale,
                    center = Offset(cx + (sx * scale), cy + (sy * scale))
                )
            }
        }
    }
}

private fun DrawScope.drawAngelWing(
    cx: Float,
    cy: Float,
    scale: Float,
    isLeft: Boolean
) {
    val dir = if (isLeft) -1f else 1f
    val wingStart = Offset(cx + (dir * 18f * scale), cy - (8f * scale))

    // Main Outer Wing Arc
    val wingPath = Path().apply {
        moveTo(wingStart.x, wingStart.y)
        cubicTo(
            cx + (dir * 55f * scale), cy - (45f * scale),
            cx + (dir * 95f * scale), cy - (95f * scale),
            cx + (dir * 135f * scale), cy - (90f * scale)
        )
        cubicTo(
            cx + (dir * 145f * scale), cy - (45f * scale),
            cx + (dir * 125f * scale), cy + (10f * scale),
            cx + (dir * 85f * scale), cy + (45f * scale)
        )
        cubicTo(
            cx + (dir * 60f * scale), cy + (48f * scale),
            cx + (dir * 45f * scale), cy + (32f * scale),
            wingStart.x, wingStart.y
        )
        close()
    }

    drawPath(
        path = wingPath,
        brush = Brush.linearGradient(
            colors = listOf(NovelAccentGold, NovelPrimary, Color(0xFFD97706)),
            start = Offset(wingStart.x, wingStart.y),
            end = Offset(cx + (dir * 135f * scale), cy - (90f * scale))
        )
    )

    // Inner Layered Feather Accents
    val featherPath = Path().apply {
        moveTo(wingStart.x + (dir * 5f * scale), wingStart.y)
        cubicTo(
            cx + (dir * 50f * scale), cy - (35f * scale),
            cx + (dir * 85f * scale), cy - (70f * scale),
            cx + (dir * 115f * scale), cy - (65f * scale)
        )
        cubicTo(
            cx + (dir * 120f * scale), cy - (30f * scale),
            cx + (dir * 95f * scale), cy + (15f * scale),
            cx + (dir * 65f * scale), cy + (30f * scale)
        )
        close()
    }
    drawPath(
        path = featherPath,
        color = Color(0xFFFFFBEB).copy(alpha = 0.85f)
    )
}
