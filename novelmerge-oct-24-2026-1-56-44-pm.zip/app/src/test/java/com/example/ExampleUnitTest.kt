package com.example

import com.example.util.NaturalOrderComparator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun naturalOrderComparator_sortsNumerically() {
        val list = listOf(
            "Chapter 10.rar",
            "Chapter 2.rar",
            "Chapter 1.rar",
            "Chapter 20.rar",
            "Chapter 3.rar"
        )
        val sorted = list.sortedWith(NaturalOrderComparator())
        assertEquals("Chapter 1.rar", sorted[0])
        assertEquals("Chapter 2.rar", sorted[1])
        assertEquals("Chapter 3.rar", sorted[2])
        assertEquals("Chapter 10.rar", sorted[3])
        assertEquals("Chapter 20.rar", sorted[4])
    }

    @Test
    fun extractChapterNumber_detectsVariations() {
        assertEquals(1, NaturalOrderComparator.extractChapterNumber("Chapter 1.rar", 1))
        assertEquals(12, NaturalOrderComparator.extractChapterNumber("Steins_Gate_Ch_12.zip", 1))
        assertEquals(25, NaturalOrderComparator.extractChapterNumber("bolum 25.rar", 1))
        assertEquals(5, NaturalOrderComparator.extractChapterNumber("c5_final.cbz", 1))
    }

    @Test
    fun cleanChapterTitle_createsReadableStrings() {
        val title = NaturalOrderComparator.cleanChapterTitle("chapter_03_the_beginning.rar", 3)
        assertTrue(title.contains("Chapter 03", ignoreCase = true))
    }
}
