package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Solar Crusader & Obsidian Ember Theme — derived directly from the Holy Sun Knight artwork
val DarkBackground = Color(0xFF0C0A09)       // Deep volcanic obsidian / scorched earth
val DarkSurface = Color(0xFF171311)          // Burnished knight armor / dark ironwood
val DarkSurfaceElevated = Color(0xFF241C17)  // Warm charcoal / volcanic slate
val DarkSurfaceBorder = Color(0xFF3E2F23)    // Weathered ancient bronze trim

// Radiant Solar & Incandescent Flame Palette
val NovelPrimary = Color(0xFFD97706)         // Blazing solar flare / golden amber
val NovelPrimaryLight = Color(0xFFFBBF24)    // Radiant sunburst halo gold
val NovelSecondary = Color(0xFFEA580C)       // Molten crusader flame / deep orange
val NovelSecondaryLight = Color(0xFFFB923C)  // Warm ember glow
val NovelAccentGold = Color(0xFFFDE047)      // Celestial divine light highlight
val NovelAccentGreen = Color(0xFF10B981)     // Emerald runic seal

// Warm Alabaster & Weathered Armor Plate Text
val TextPrimaryDark = Color(0xFFFFFBEB)      // Warm parchment ivory
val TextSecondaryDark = Color(0xFFE7E5E4)    // Weathered silver-gray
val TextMuted = Color(0xFFA8A29E)            // Ashen stone

// Light theme tokens (Warm antique parchment & gilded bronze)
val LightBackground = Color(0xFFFAF6F0)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF4ECE4)
val LightPrimary = Color(0xFFD97706)
