package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.NavigateBefore
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Chapter
import com.example.model.FitMode
import com.example.model.NovelPage
import com.example.model.ReaderSettings
import com.example.model.ReaderTheme
import com.example.model.ReadingDirection
import com.example.model.ReadingMode
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NovelAccentGold
import com.example.ui.theme.NovelPrimary
import com.example.ui.theme.NovelSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.viewmodel.AppScreen
import com.example.viewmodel.NovelViewModel
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(viewModel: NovelViewModel) {
    val novel by viewModel.selectedNovel.collectAsState()
    val chapter by viewModel.currentReadingChapter.collectAsState()
    val pages by viewModel.currentChapterPages.collectAsState()
    val initialPageIndex by viewModel.currentReadingPageIndex.collectAsState()
    val chapters by viewModel.chapters.collectAsState()
    val settings by viewModel.readerSettings.collectAsState()

    val scope = rememberCoroutineScope()

    // Controls visibility
    var showControls by remember { mutableStateOf(true) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showChapterPickerSheet by remember { mutableStateOf(false) }

    // Back navigation returns to chapter list
    BackHandler {
        viewModel.navigateTo(AppScreen.CHAPTER_LIST)
    }

    if (novel == null || chapter == null || pages.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Bölüm sayfaları yükleniyor...", color = Color.White)
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = { viewModel.navigateTo(AppScreen.CHAPTER_LIST) }) {
                    Text("Geri Dön")
                }
            }
        }
        return
    }

    val currentChapter = chapter!!
    val totalPages = pages.size

    val readerBgColor = Color(settings.theme.bgHex)
    val readerTextColor = if (settings.theme.isDark) Color.White else Color.Black

    // Pager state for Horizontal mode
    val pagerState = rememberPagerState(
        initialPage = initialPageIndex.coerceIn(0, (totalPages - 1).coerceAtLeast(0)),
        pageCount = { totalPages }
    )

    // LazyList state for Vertical Webtoon mode
    val lazyListState = rememberLazyListState(
        initialFirstVisibleItemIndex = initialPageIndex.coerceIn(0, (totalPages - 1).coerceAtLeast(0))
    )

    // Track visible page index in Webtoon mode
    LaunchedEffect(lazyListState) {
        snapshotFlow { lazyListState.firstVisibleItemIndex }.collect { index ->
            if (settings.readingMode == ReadingMode.WEBTOON) {
                viewModel.onPageChanged(index)
            }
        }
    }

    // Track visible page index in Paged mode
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { index ->
            if (settings.readingMode == ReadingMode.PAGED) {
                viewModel.onPageChanged(index)
            }
        }
    }

    val currentPageIndex = if (settings.readingMode == ReadingMode.WEBTOON) {
        lazyListState.firstVisibleItemIndex
    } else {
        pagerState.currentPage
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(readerBgColor)
    ) {
        // Main Content: either Webtoon or Paged (All chapters unified in one seamless book)
        if (settings.readingMode == ReadingMode.WEBTOON) {
            LazyColumn(
                state = lazyListState,
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { showControls = !showControls }
                        )
                    }
                    .testTag("reader_webtoon_list")
            ) {
                itemsIndexed(pages, key = { index, page -> "${page.chapterId}_${page.pageNumber}_$index" }) { pageIndex, page ->
                    // Seamless Chapter Divider: Shown between chapters in the continuous scroll
                    if (page.pageNumber == 1 && page.chapterIndex > 1) {
                        ChapterBreakBanner(
                            chapterTitle = page.chapterTitle,
                            chapterIndex = page.chapterIndex
                        )
                    }

                    WebtoonPageItem(
                        page = page,
                        fitMode = settings.fitMode
                    )
                }

                // Celebratory completion card at the very end of the whole book
                item {
                    EndOfNovelCelebrationCard(
                        novelTitle = novel?.title ?: "Görsel Roman",
                        totalPages = pages.size,
                        totalChapters = chapters.size,
                        onRestart = {
                            scope.launch {
                                lazyListState.scrollToItem(0)
                                viewModel.onPageChanged(0)
                            }
                        },
                        onBackToChapters = { viewModel.navigateTo(AppScreen.CHAPTER_LIST) }
                    )
                }
            }
        } else {
            // Horizontal Paged Mode
            val isRtl = settings.readingDirection == ReadingDirection.RIGHT_TO_LEFT
            HorizontalPager(
                state = pagerState,
                reverseLayout = isRtl,
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { showControls = !showControls }
                        )
                    }
                    .testTag("reader_paged_pager")
            ) { pageIndex ->
                val page = pages[pageIndex]
                ZoomablePagedItem(
                    page = page,
                    fitMode = settings.fitMode,
                    onTap = { showControls = !showControls }
                )
            }
        }

        // Top Overlay Bar
        AnimatedVisibility(
            visible = showControls,
            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.85f),
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppScreen.CHAPTER_LIST) },
                        modifier = Modifier.testTag("btn_reader_back")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Geri",
                            tint = Color.White
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 8.dp)
                    ) {
                        Text(
                            text = novel?.title ?: "",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val activePage = pages.getOrNull(currentPageIndex)
                        val globalNum = activePage?.globalPageNumber ?: (currentPageIndex + 1)
                        Text(
                            text = "${currentChapter.title} • Sayfa ${currentPageIndex + 1}/$totalPages (Genel Sıra: #$globalNum)",
                            color = NovelAccentGold,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }

                    IconButton(
                        onClick = { showChapterPickerSheet = true },
                        modifier = Modifier.testTag("btn_reader_chapter_picker")
                    ) {
                        Icon(
                            Icons.Default.FormatListNumbered,
                            contentDescription = "Bölüm Seç",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier.testTag("btn_reader_settings")
                    ) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Ayarlar",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        // Bottom Overlay Bar
        AnimatedVisibility(
            visible = showControls,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.88f),
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    // Page Scrubber Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${currentPageIndex + 1}",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(36.dp),
                            textAlign = TextAlign.Center
                        )

                        Slider(
                            value = (currentPageIndex + 1).toFloat(),
                            onValueChange = { value ->
                                val targetPage = (value.toInt() - 1).coerceIn(0, totalPages - 1)
                                scope.launch {
                                    if (settings.readingMode == ReadingMode.WEBTOON) {
                                        lazyListState.scrollToItem(targetPage)
                                    } else {
                                        pagerState.scrollToPage(targetPage)
                                    }
                                    viewModel.onPageChanged(targetPage)
                                }
                            },
                            valueRange = 1f..totalPages.toFloat().coerceAtLeast(1f),
                            steps = if (totalPages > 2) totalPages - 2 else 0,
                            colors = SliderDefaults.colors(
                                thumbColor = NovelPrimary,
                                activeTrackColor = NovelPrimary,
                                inactiveTrackColor = Color.DarkGray
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("slider_page_scrubber")
                        )

                        Text(
                            text = "$totalPages",
                            color = TextSecondaryDark,
                            fontSize = 12.sp,
                            modifier = Modifier.width(36.dp),
                            textAlign = TextAlign.Center
                        )
                    }

                    // Chapter Navigation Row
                    val currentChapterIdx = chapters.indexOfFirst { it.id == currentChapter.id }
                    val hasPrevChapter = currentChapterIdx > 0
                    val hasNextChapter = currentChapterIdx != -1 && currentChapterIdx < chapters.size - 1

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                val targetIdx = viewModel.previousChapter()
                                if (targetIdx >= 0) {
                                    scope.launch {
                                        if (settings.readingMode == ReadingMode.WEBTOON) {
                                            lazyListState.scrollToItem(targetIdx)
                                        } else {
                                            pagerState.scrollToPage(targetIdx)
                                        }
                                    }
                                }
                            },
                            enabled = hasPrevChapter,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DarkSurfaceElevated,
                                disabledContainerColor = Color.Transparent
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btn_prev_chapter")
                        ) {
                            Icon(Icons.Default.NavigateBefore, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Önceki Bölüm", fontSize = 11.sp, color = Color.White)
                        }

                        // Thumbnail drawer toggle
                        Text(
                            text = "${currentChapter.title}",
                            color = NovelAccentGold,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        Button(
                            onClick = {
                                val targetIdx = viewModel.nextChapter()
                                if (targetIdx >= 0) {
                                    scope.launch {
                                        if (settings.readingMode == ReadingMode.WEBTOON) {
                                            lazyListState.scrollToItem(targetIdx)
                                        } else {
                                            pagerState.scrollToPage(targetIdx)
                                        }
                                    }
                                }
                            },
                            enabled = hasNextChapter,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NovelPrimary,
                                disabledContainerColor = Color.Transparent
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btn_next_chapter")
                        ) {
                            Text("Sonraki Bölüm", fontSize = 11.sp, color = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Default.NavigateNext, contentDescription = null, tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Thumbnail carousel strip along bottom
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(64.dp)
                    ) {
                        itemsIndexed(pages) { idx, p ->
                            val isSelected = idx == currentPageIndex
                            Box(
                                modifier = Modifier
                                    .size(width = 44.dp, height = 64.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .border(
                                        2.dp,
                                        if (isSelected) NovelPrimary else Color.Transparent,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .clickable {
                                        scope.launch {
                                            if (settings.readingMode == ReadingMode.WEBTOON) {
                                                lazyListState.scrollToItem(idx)
                                            } else {
                                                pagerState.scrollToPage(idx)
                                            }
                                            viewModel.onPageChanged(idx)
                                        }
                                    }
                            ) {
                                AsyncImage(
                                    model = File(p.absoluteFilePath),
                                    contentDescription = "Sayfa ${idx + 1}",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .background(Color.Black.copy(alpha = 0.7f))
                                        .fillMaxWidth()
                                ) {
                                    Text(
                                        text = "${idx + 1}",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Reader Settings Modal BottomSheet
    if (showSettingsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSettingsSheet = false },
            containerColor = DarkSurfaceElevated,
            sheetState = rememberModalBottomSheetState()
        ) {
            ReaderSettingsContent(
                settings = settings,
                onSettingsChange = { newSettings ->
                    viewModel.updateReaderSettings(newSettings)
                }
            )
        }
    }

    // Chapter Picker Modal BottomSheet
    if (showChapterPickerSheet) {
        ModalBottomSheet(
            onDismissRequest = { showChapterPickerSheet = false },
            containerColor = DarkSurfaceElevated,
            sheetState = rememberModalBottomSheetState()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .navigationBarsPadding()
            ) {
                Text(
                    text = "Bölüm Seç",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxHeight(0.6f)
                ) {
                    items(chapters) { ch ->
                        val isSelected = ch.id == currentChapter.id
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showChapterPickerSheet = false
                                    val targetIdx = viewModel.jumpToChapter(ch.id)
                                    if (targetIdx >= 0) {
                                        scope.launch {
                                            if (settings.readingMode == ReadingMode.WEBTOON) {
                                                lazyListState.scrollToItem(targetIdx)
                                            } else {
                                                pagerState.scrollToPage(targetIdx)
                                            }
                                        }
                                    }
                                }
                                .border(
                                    1.dp,
                                    if (isSelected) NovelPrimary else DarkSurfaceBorder,
                                    RoundedCornerShape(10.dp)
                                ),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) NovelPrimary.copy(alpha = 0.2f) else DarkSurface
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = ch.title,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSelected) NovelPrimary else TextPrimaryDark
                                    )
                                    Text(
                                        text = "${ch.pageCount} Sayfa",
                                        fontSize = 11.sp,
                                        color = TextSecondaryDark
                                    )
                                }
                                if (isSelected) {
                                    Text(
                                        text = "Okunuyor",
                                        fontSize = 12.sp,
                                        color = NovelAccentGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WebtoonPageItem(
    page: NovelPage,
    fitMode: FitMode
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = File(page.absoluteFilePath),
            contentDescription = "Sayfa ${page.pageNumber}",
            contentScale = if (fitMode == FitMode.FIT_WIDTH) ContentScale.FillWidth else ContentScale.Fit,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun ZoomablePagedItem(
    page: NovelPage,
    fitMode: FitMode,
    onTap: () -> Unit
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        scale = if (scale > 1.5f) 1f else 2.5f
                        offset = Offset.Zero
                    },
                    onTap = { onTap() }
                )
            }
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 4f)
                    if (scale > 1f) {
                        offset += pan
                    } else {
                        offset = Offset.Zero
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = File(page.absoluteFilePath),
            contentDescription = "Sayfa ${page.pageNumber}",
            contentScale = if (fitMode == FitMode.FIT_WIDTH) ContentScale.FillWidth else ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
        )
    }
}

@Composable
fun ChapterBreakBanner(
    chapterTitle: String,
    chapterIndex: Int
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkBackground)
            .padding(vertical = 32.dp, horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(
                    androidx.compose.ui.graphics.Brush.verticalGradient(
                        listOf(DarkSurfaceElevated, DarkSurface)
                    )
                )
                .border(1.dp, NovelPrimary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(vertical = 20.dp, horizontal = 16.dp)
        ) {
            Surface(
                color = NovelPrimary,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.padding(bottom = 10.dp)
            ) {
                Text(
                    text = "BÖLÜM $chapterIndex BAŞLANGICI",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                )
            }
            Text(
                text = chapterTitle,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryDark,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Tek Kitap Akışı • Okumaya Doğrudan Aşağı Kaydırarak Devam Edin ↓",
                fontSize = 11.sp,
                color = NovelAccentGold,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun EndOfNovelCelebrationCard(
    novelTitle: String,
    totalPages: Int,
    totalChapters: Int,
    onRestart: () -> Unit,
    onBackToChapters: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, NovelPrimary.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(NovelPrimary.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = NovelAccentGold,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "Tebrikler!",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryDark
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "'$novelTitle' görsel romanının tüm $totalChapters bölümünü ($totalPages sayfa) tek parça halinde tamamladınız.",
                fontSize = 13.sp,
                color = TextSecondaryDark,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )
            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onRestart,
                colors = ButtonDefaults.buttonColors(containerColor = NovelPrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(46.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Baştan Oku (Sayfa 1)", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = onBackToChapters,
                colors = ButtonDefaults.buttonColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(46.dp)
            ) {
                Text("Bölüm Listesine Dön", color = TextPrimaryDark)
            }
        }
    }
}

@Composable
fun ReaderSettingsContent(
    settings: ReaderSettings,
    onSettingsChange: (ReaderSettings) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp)
            .navigationBarsPadding()
    ) {
        Text(
            text = "Okuyucu Ayarları",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimaryDark
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Okuma Modu (Webtoon vs Paged)
        Text(text = "Okuma Modu", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextSecondaryDark)
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = settings.readingMode == ReadingMode.WEBTOON,
                onClick = { onSettingsChange(settings.copy(readingMode = ReadingMode.WEBTOON)) },
                label = { Text("Dikey Akış (Webtoon)") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NovelPrimary,
                    selectedLabelColor = Color.White
                )
            )
            FilterChip(
                selected = settings.readingMode == ReadingMode.PAGED,
                onClick = { onSettingsChange(settings.copy(readingMode = ReadingMode.PAGED)) },
                label = { Text("Sayfa Sayfa") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NovelPrimary,
                    selectedLabelColor = Color.White
                )
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Sayfa Çevirme Yönü (LTR vs RTL)
        if (settings.readingMode == ReadingMode.PAGED) {
            Text(text = "Sayfa Yönü", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextSecondaryDark)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = settings.readingDirection == ReadingDirection.LEFT_TO_RIGHT,
                    onClick = { onSettingsChange(settings.copy(readingDirection = ReadingDirection.LEFT_TO_RIGHT)) },
                    label = { Text("Soldan Sağa") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NovelPrimary,
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = settings.readingDirection == ReadingDirection.RIGHT_TO_LEFT,
                    onClick = { onSettingsChange(settings.copy(readingDirection = ReadingDirection.RIGHT_TO_LEFT)) },
                    label = { Text("Sağdan Sola (Manga)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NovelPrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Arka Plan Rengi
        Text(text = "Arka Plan Rengi", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextSecondaryDark)
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val themes = listOf(
                Pair(ReaderTheme.AMOLED_BLACK, "AMOLED Siyah"),
                Pair(ReaderTheme.SLATE_DARK, "Koyu Füme"),
                Pair(ReaderTheme.SEPIA, "Sıcak Sepya"),
                Pair(ReaderTheme.LIGHT, "Açık")
            )
            themes.forEach { (theme, label) ->
                val isSelected = settings.theme == theme
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(theme.bgHex))
                        .border(
                            2.dp,
                            if (isSelected) NovelPrimary else Color.Gray.copy(alpha = 0.5f),
                            CircleShape
                        )
                        .clickable { onSettingsChange(settings.copy(theme = theme)) },
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(NovelPrimary)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Görüntü Uyumu
        Text(text = "Görüntü Uyumu", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextSecondaryDark)
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = settings.fitMode == FitMode.FIT_WIDTH,
                onClick = { onSettingsChange(settings.copy(fitMode = FitMode.FIT_WIDTH)) },
                label = { Text("Genişliğe Sığdır") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NovelPrimary,
                    selectedLabelColor = Color.White
                )
            )
            FilterChip(
                selected = settings.fitMode == FitMode.FIT_SCREEN,
                onClick = { onSettingsChange(settings.copy(fitMode = FitMode.FIT_SCREEN)) },
                label = { Text("Ekrana Sığdır") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NovelPrimary,
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}
