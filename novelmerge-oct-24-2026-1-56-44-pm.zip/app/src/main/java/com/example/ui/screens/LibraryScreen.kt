package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.NovelWork
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NovelAccentGold
import com.example.ui.theme.NovelPrimary
import com.example.ui.theme.NovelPrimaryLight
import com.example.ui.theme.NovelSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.viewmodel.AppScreen
import com.example.viewmodel.NovelViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(viewModel: NovelViewModel) {
    val context = LocalContext.current
    val novels by viewModel.filteredNovels.collectAsState(initial = emptyList())
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isGridView by viewModel.isGridView.collectAsState()
    var isSearchActive by remember { mutableStateOf(false) }

    // Dialog state for renaming
    var renameTargetNovel by remember { mutableStateOf<NovelWork?>(null) }
    var renameInputText by remember { mutableStateOf("") }

    // Dialog state for delete confirmation
    var deleteTargetNovel by remember { mutableStateOf<NovelWork?>(null) }

    // Document export launcher for saving unified CBZ
    var exportTargetNovelId by remember { mutableStateOf<String?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null && exportTargetNovelId != null) {
            context.contentResolver.openOutputStream(uri)?.use { stream ->
                viewModel.exportNovel(exportTargetNovelId!!, stream)
            }
        }
        exportTargetNovelId = null
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground),
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimaryDark
                ),
                title = {
                    if (isSearchActive) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.setSearchQuery(it) },
                            placeholder = { Text("Görsel roman ara...", color = TextMuted) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("search_input"),
                            trailingIcon = {
                                IconButton(onClick = {
                                    viewModel.setSearchQuery("")
                                    isSearchActive = false
                                }) {
                                    Icon(Icons.Default.Close, contentDescription = "Aramayı Kapat")
                                }
                            }
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(NovelPrimaryLight, NovelSecondary)
                                        )
                                    )
                                    .border(1.5.dp, Brush.linearGradient(listOf(NovelAccentGold, NovelPrimary)), CircleShape)
                                    .padding(1.5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(com.example.R.drawable.ic_sun_paladin_logo),
                                    contentDescription = "Güneş Şövalyesi Logosu",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Kitaplığım",
                                    fontSize = 19.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimaryDark
                                )
                                Text(
                                    text = "Tek Cilt Görsel Romanlar",
                                    fontSize = 11.sp,
                                    color = TextSecondaryDark
                                )
                            }
                        }
                    }
                },
                actions = {
                    if (!isSearchActive) {
                        IconButton(
                            onClick = { isSearchActive = true },
                            modifier = Modifier.testTag("action_search")
                        ) {
                            Icon(Icons.Default.Search, contentDescription = "Ara", tint = TextPrimaryDark)
                        }
                    }
                    IconButton(
                        onClick = { viewModel.toggleGridView() },
                        modifier = Modifier.testTag("action_toggle_view")
                    ) {
                        Icon(
                            if (isGridView) Icons.Default.ViewList else Icons.Default.GridView,
                            contentDescription = "Görünümü Değiştir",
                            tint = TextPrimaryDark
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo(AppScreen.MERGE_STUDIO) },
                containerColor = NovelPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .navigationBarsPadding()
                    .padding(bottom = 8.dp)
                    .testTag("fab_merge_chapters")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Bölüm Ekle")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Bölüm Birleştir",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Stats & Quick Action Bar
            HeaderStatsCard(
                novelCount = novels.size,
                totalChapters = novels.sumOf { it.chapterCount },
                onAddSample = { viewModel.loadDemoSample() },
                onOpenMerge = { viewModel.navigateTo(AppScreen.MERGE_STUDIO) }
            )

            if (novels.isEmpty()) {
                EmptyLibraryView(
                    onOpenMergeStudio = { viewModel.navigateTo(AppScreen.MERGE_STUDIO) },
                    onLoadDemo = { viewModel.loadDemoSample() }
                )
            } else {
                if (isGridView) {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 160.dp),
                        contentPadding = PaddingValues(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("novels_grid")
                    ) {
                        items(novels, key = { it.id }) { novel ->
                            NovelGridCard(
                                novel = novel,
                                onClick = { viewModel.openNovel(novel.id) },
                                onResume = { viewModel.startReading(novel.id, novel.lastReadChapterId, novel.lastReadPageIndex) },
                                onToggleFav = { viewModel.toggleFavorite(novel.id) },
                                onRename = {
                                    renameTargetNovel = novel
                                    renameInputText = novel.title
                                },
                                onExport = {
                                    exportTargetNovelId = novel.id
                                    exportLauncher.launch("${novel.title.replace(" ", "_")}_Unified.cbz")
                                },
                                onDelete = { deleteTargetNovel = novel }
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("novels_list")
                    ) {
                        items(novels, key = { it.id }) { novel ->
                            NovelListCard(
                                novel = novel,
                                onClick = { viewModel.openNovel(novel.id) },
                                onResume = { viewModel.startReading(novel.id, novel.lastReadChapterId, novel.lastReadPageIndex) },
                                onToggleFav = { viewModel.toggleFavorite(novel.id) },
                                onRename = {
                                    renameTargetNovel = novel
                                    renameInputText = novel.title
                                },
                                onExport = {
                                    exportTargetNovelId = novel.id
                                    exportLauncher.launch("${novel.title.replace(" ", "_")}_Unified.cbz")
                                },
                                onDelete = { deleteTargetNovel = novel }
                            )
                        }
                    }
                }
            }
        }
    }

    // Rename Dialog
    renameTargetNovel?.let { novel ->
        AlertDialog(
            onDismissRequest = { renameTargetNovel = null },
            title = { Text("Görsel Romanı Yeniden Adlandır", color = TextPrimaryDark) },
            text = {
                OutlinedTextField(
                    value = renameInputText,
                    onValueChange = { renameInputText = it },
                    singleLine = true,
                    label = { Text("Roman Başlığı") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rename_input_field")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (renameInputText.isNotBlank()) {
                            viewModel.renameNovel(novel.id, renameInputText)
                        }
                        renameTargetNovel = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NovelPrimary)
                ) {
                    Text("Kaydet")
                }
            },
            dismissButton = {
                TextButton(onClick = { renameTargetNovel = null }) {
                    Text("İptal", color = TextSecondaryDark)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }

    // Delete Confirmation Dialog
    deleteTargetNovel?.let { novel ->
        AlertDialog(
            onDismissRequest = { deleteTargetNovel = null },
            title = { Text("Romanı Sil", color = TextPrimaryDark) },
            text = {
                Text(
                    "'${novel.title}' ve birleştirilen tüm chapter dosyaları cihazınızdan silinecektir. Devam etmek istiyor musunuz?",
                    color = TextSecondaryDark
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteNovel(novel.id)
                        deleteTargetNovel = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Sil", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteTargetNovel = null }) {
                    Text("İptal", color = TextSecondaryDark)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }
}

@Composable
fun HeaderStatsCard(
    novelCount: Int,
    totalChapters: Int,
    onAddSample: () -> Unit,
    onOpenMerge: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(
                        text = "$novelCount Kitap • $totalChapters Bölüm",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )
                    Text(
                        text = "1080p optimize edilmiş tek ciltler",
                        fontSize = 12.sp,
                        color = TextSecondaryDark
                    )
                }
            }

            Row {
                TextButton(
                    onClick = onAddSample,
                    modifier = Modifier.testTag("btn_load_sample")
                ) {
                    Icon(
                        Icons.Default.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = NovelAccentGold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "Örnek Kitap",
                        color = NovelAccentGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun NovelGridCard(
    novel: NovelWork,
    onClick: () -> Unit,
    onResume: () -> Unit,
    onToggleFav: () -> Unit,
    onRename: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
            .testTag("novel_card_${novel.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column {
            // Cover Image with Badges
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.72f)
                    .background(DarkSurfaceElevated)
            ) {
                if (novel.coverPath != null && File(novel.coverPath).exists()) {
                    AsyncImage(
                        model = File(novel.coverPath),
                        contentDescription = novel.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(NovelPrimary.copy(alpha = 0.4f), DarkSurfaceElevated)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Book,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                    }
                }

                // Top Bar with Favorite and Menu
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onToggleFav,
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(
                            if (novel.isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Favori",
                            tint = if (novel.isFavorite) NovelAccentGold else Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Box {
                        IconButton(
                            onClick = { menuExpanded = true },
                            modifier = Modifier
                                .size(32.dp)
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(
                                Icons.Default.MoreVert,
                                contentDescription = "Seçenekler",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false },
                            modifier = Modifier.background(DarkSurfaceElevated)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Okumaya Başla", color = TextPrimaryDark) },
                                leadingIcon = { Icon(Icons.Default.PlayArrow, null, tint = NovelPrimary) },
                                onClick = {
                                    menuExpanded = false
                                    onResume()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Tek Parça CBZ İndir", color = TextPrimaryDark) },
                                leadingIcon = { Icon(Icons.Default.FolderZip, null, tint = NovelSecondary) },
                                onClick = {
                                    menuExpanded = false
                                    onExport()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Yeniden Adlandır", color = TextPrimaryDark) },
                                leadingIcon = { Icon(Icons.Default.Edit, null, tint = TextSecondaryDark) },
                                onClick = {
                                    menuExpanded = false
                                    onRename()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Kütüphaneden Sil", color = Color(0xFFEF4444)) },
                                leadingIcon = { Icon(Icons.Default.Delete, null, tint = Color(0xFFEF4444)) },
                                onClick = {
                                    menuExpanded = false
                                    onDelete()
                                }
                            )
                        }
                    }
                }

                // Chapter count pill
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.Black.copy(alpha = 0.75f),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                ) {
                    Text(
                        text = "${novel.chapterCount} Bölüm",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Title & Info
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = novel.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${novel.pageCount} Sayfa • Birleştirildi",
                    fontSize = 11.sp,
                    color = TextSecondaryDark
                )

                Spacer(modifier = Modifier.height(8.dp))
                // Progress Bar
                LinearProgressIndicator(
                    progress = { novel.progressPercent },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(CircleShape),
                    color = NovelPrimary,
                    trackColor = DarkSurfaceElevated
                )

                Spacer(modifier = Modifier.height(8.dp))
                // Quick Resume Button
                Button(
                    onClick = onResume,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(34.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NovelPrimary.copy(alpha = 0.2f)),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = NovelPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (novel.lastReadPageIndex > 0) "Devam Et" else "Oku",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NovelPrimary
                    )
                }
            }
        }
    }
}

@Composable
fun NovelListCard(
    novel: NovelWork,
    onClick: () -> Unit,
    onResume: () -> Unit,
    onToggleFav: () -> Unit,
    onRename: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .size(width = 68.dp, height = 90.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurfaceElevated)
            ) {
                if (novel.coverPath != null && File(novel.coverPath).exists()) {
                    AsyncImage(
                        model = File(novel.coverPath),
                        contentDescription = novel.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Book, null, tint = TextMuted)
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Info
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = novel.title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (novel.isFavorite) {
                        Icon(
                            Icons.Default.Bookmark,
                            contentDescription = null,
                            tint = NovelAccentGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${novel.chapterCount} Bölüm • Toplam ${novel.pageCount} Sayfa",
                    fontSize = 12.sp,
                    color = TextSecondaryDark
                )

                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { novel.progressPercent },
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(4.dp)
                        .clip(CircleShape),
                    color = NovelPrimary,
                    trackColor = DarkSurfaceElevated
                )
            }

            // Actions
            IconButton(onClick = onResume) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Oku", tint = NovelPrimary)
            }

            Box {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Daha Fazla", tint = TextSecondaryDark)
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier.background(DarkSurfaceElevated)
                ) {
                    DropdownMenuItem(
                        text = { Text("Bölümleri Aç", color = TextPrimaryDark) },
                        onClick = {
                            menuExpanded = false
                            onClick()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(if (novel.isFavorite) "Favorilerden Çıkar" else "Favorilere Ekle", color = TextPrimaryDark) },
                        onClick = {
                            menuExpanded = false
                            onToggleFav()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Tek Parça CBZ İndir", color = TextPrimaryDark) },
                        onClick = {
                            menuExpanded = false
                            onExport()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Yeniden Adlandır", color = TextPrimaryDark) },
                        onClick = {
                            menuExpanded = false
                            onRename()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Sil", color = Color(0xFFEF4444)) },
                        onClick = {
                            menuExpanded = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyLibraryView(
    onOpenMergeStudio: () -> Unit,
    onLoadDemo: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(104.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(NovelPrimaryLight, NovelSecondary)
                        )
                    )
                    .border(2.dp, Brush.linearGradient(listOf(NovelAccentGold, NovelPrimary)), CircleShape)
                    .padding(2.5.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(com.example.R.drawable.ic_sun_paladin_logo),
                    contentDescription = "Güneş Şövalyesi",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Kitaplığın Henüz Boş",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryDark
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Okumak istediğin eserin tüm bölüm dosyalarını (ZIP / RAR) seçip tek bir kitap halinde birleştirebilir ve hemen okumaya başlayabilirsin.",
                fontSize = 13.sp,
                color = TextSecondaryDark,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                lineHeight = 19.sp
            )

            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onOpenMergeStudio,
                colors = ButtonDefaults.buttonColors(containerColor = NovelPrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(48.dp)
                    .testTag("btn_empty_merge")
            ) {
                Icon(Icons.Default.FileUpload, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Bölüm Dosyalarını Seç ve Birleştir", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(12.dp))
            TextButton(
                onClick = onLoadDemo,
                modifier = Modifier.testTag("btn_empty_demo")
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = NovelAccentGold)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Hazır Örnek Kitabı Yükle (3 Bölüm)", color = NovelAccentGold, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
