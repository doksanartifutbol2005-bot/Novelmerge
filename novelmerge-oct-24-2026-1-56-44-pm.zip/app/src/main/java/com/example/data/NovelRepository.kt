package com.example.data

import android.content.Context
import android.net.Uri
import com.example.model.Chapter
import com.example.model.NovelPage
import com.example.model.NovelWork
import com.example.model.PendingArchiveItem
import com.example.model.ReaderSettings
import com.example.util.ArchiveExtractor
import com.example.util.NaturalOrderComparator
import com.example.util.SampleNovelGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.util.UUID

class NovelRepository(private val context: Context) {

    private val baseNovelsDir = File(context.filesDir, "novels").apply { mkdirs() }
    private val tempDir = File(context.cacheDir, "archive_temp").apply { mkdirs() }

    private val _novels = MutableStateFlow<List<NovelWork>>(emptyList())
    val novels: StateFlow<List<NovelWork>> = _novels.asStateFlow()

    private val _readerSettings = MutableStateFlow(ReaderSettings())
    val readerSettings: StateFlow<ReaderSettings> = _readerSettings.asStateFlow()

    suspend fun initialize() = withContext(Dispatchers.IO) {
        // If library is completely empty, populate demo novel so user has immediate content
        val existingFolders = baseNovelsDir.listFiles()?.filter { it.isDirectory } ?: emptyList()
        if (existingFolders.isEmpty()) {
            val sampleDir = SampleNovelGenerator.createSampleNovel(context, baseNovelsDir)
            saveNovelMetadata(
                NovelWork(
                    id = sampleDir.name,
                    title = "Yıldız Işığı Anıları (Demo)",
                    description = "Görsel Roman • 3 Bölüm Tek Parça Olarak Birleştirildi",
                    coverPath = File(sampleDir, "cover.jpg").absolutePath,
                    chapterCount = 3,
                    pageCount = 9,
                    lastReadChapterId = "chapter_001",
                    lastReadPageIndex = 0,
                    totalStorageBytes = calculateFolderSize(sampleDir),
                    createdAt = System.currentTimeMillis()
                )
            )
        }
        refreshNovelsList()
    }

    suspend fun refreshNovelsList() = withContext(Dispatchers.IO) {
        val novelFolders = baseNovelsDir.listFiles()?.filter { it.isDirectory } ?: emptyList()
        val loadedNovels = mutableListOf<NovelWork>()

        for (folder in novelFolders) {
            val metaFile = File(folder, "novel.json")
            if (metaFile.exists()) {
                try {
                    val json = JSONObject(metaFile.readText())
                    loadedNovels.add(
                        NovelWork(
                            id = json.getString("id"),
                            title = json.getString("title"),
                            description = json.optString("description", ""),
                            coverPath = json.optString("coverPath").ifBlank { null },
                            chapterCount = json.optInt("chapterCount", 0),
                            pageCount = json.optInt("pageCount", 0),
                            lastReadChapterId = json.optString("lastReadChapterId").ifBlank { null },
                            lastReadPageIndex = json.optInt("lastReadPageIndex", 0),
                            totalStorageBytes = json.optLong("totalStorageBytes", calculateFolderSize(folder)),
                            createdAt = json.optLong("createdAt", folder.lastModified()),
                            lastReadAt = json.optLong("lastReadAt", folder.lastModified()),
                            isFavorite = json.optBoolean("isFavorite", false)
                        )
                    )
                } catch (_: Exception) {
                    // Rebuild metadata if json corrupted
                    val rebuilt = scanAndRebuildNovel(folder)
                    loadedNovels.add(rebuilt)
                }
            } else {
                val rebuilt = scanAndRebuildNovel(folder)
                loadedNovels.add(rebuilt)
            }
        }

        // Sort: favorites first, then by last read / created
        loadedNovels.sortWith { a, b ->
            if (a.isFavorite != b.isFavorite) {
                b.isFavorite.compareTo(a.isFavorite)
            } else {
                b.lastReadAt.compareTo(a.lastReadAt)
            }
        }

        _novels.value = loadedNovels
    }

    private fun scanAndRebuildNovel(folder: File): NovelWork {
        val chaptersDir = File(folder, "chapters")
        val chapterFolders = chaptersDir.listFiles()?.filter { it.isDirectory } ?: emptyList()
        var totalPages = 0
        var firstPageCover: String? = null

        chapterFolders.forEach { ch ->
            val pages = ch.listFiles()?.filter { ArchiveExtractor.isImageFile(it.name) } ?: emptyList()
            totalPages += pages.size
            if (firstPageCover == null && pages.isNotEmpty()) {
                firstPageCover = pages.first().absolutePath
            }
        }

        val coverFile = File(folder, "cover.jpg")
        val finalCover = if (coverFile.exists()) coverFile.absolutePath else firstPageCover

        val novel = NovelWork(
            id = folder.name,
            title = folder.name.replace("_", " ").replaceFirstChar { it.uppercase() },
            description = "Toplu birleştirilmiş görsel roman",
            coverPath = finalCover,
            chapterCount = chapterFolders.size,
            pageCount = totalPages,
            lastReadChapterId = chapterFolders.firstOrNull()?.name,
            lastReadPageIndex = 0,
            totalStorageBytes = calculateFolderSize(folder),
            createdAt = folder.lastModified()
        )
        saveNovelMetadata(novel)
        return novel
    }

    private fun saveNovelMetadata(novel: NovelWork) {
        val folder = File(baseNovelsDir, novel.id)
        folder.mkdirs()
        val metaFile = File(folder, "novel.json")
        val json = JSONObject().apply {
            put("id", novel.id)
            put("title", novel.title)
            put("description", novel.description)
            put("coverPath", novel.coverPath ?: "")
            put("chapterCount", novel.chapterCount)
            put("pageCount", novel.pageCount)
            put("lastReadChapterId", novel.lastReadChapterId ?: "")
            put("lastReadPageIndex", novel.lastReadPageIndex)
            put("totalStorageBytes", novel.totalStorageBytes)
            put("createdAt", novel.createdAt)
            put("lastReadAt", novel.lastReadAt)
            put("isFavorite", novel.isFavorite)
        }
        metaFile.writeText(json.toString())
    }

    suspend fun getChapters(novelId: String): List<Chapter> = withContext(Dispatchers.IO) {
        val folder = File(baseNovelsDir, novelId)
        val chaptersDir = File(folder, "chapters")
        if (!chaptersDir.exists()) return@withContext emptyList()

        val list = chaptersDir.listFiles()?.filter { it.isDirectory } ?: emptyList()
        val sortedDirs = list.sortedWith { a, b -> NaturalOrderComparator().compare(a.name, b.name) }

        // Read custom chapter names if exists
        val namesFile = File(folder, "chapter_names.json")
        val customNames = mutableMapOf<String, String>()
        if (namesFile.exists()) {
            try {
                val json = JSONObject(namesFile.readText())
                val keys = json.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    customNames[k] = json.getString(k)
                }
            } catch (_: Exception) {}
        }

        sortedDirs.mapIndexed { index, dir ->
            val pages = dir.listFiles()?.filter { ArchiveExtractor.isImageFile(it.name) }
                ?.sortedWith { a, b -> NaturalOrderComparator().compare(a.name, b.name) }
                ?: emptyList()
            val thumb = pages.firstOrNull()?.absolutePath
            val title = customNames[dir.name] ?: "Bölüm ${index + 1}"

            Chapter(
                id = dir.name,
                novelId = novelId,
                chapterIndex = index + 1,
                title = title,
                pageCount = pages.size,
                folderRelativePath = "chapters/${dir.name}",
                thumbnailPath = thumb
            )
        }
    }

    suspend fun getChapterPages(novelId: String, chapterId: String): List<NovelPage> = withContext(Dispatchers.IO) {
        val chapters = getChapters(novelId)
        val currentChapter = chapters.find { it.id == chapterId }
        val chapterIndex = currentChapter?.chapterIndex ?: 1
        val chapterTitle = currentChapter?.title ?: "Bölüm $chapterIndex"

        var priorPagesCount = 0
        for (ch in chapters) {
            if (ch.id == chapterId) break
            priorPagesCount += ch.pageCount
        }

        val chapterDir = File(baseNovelsDir, "$novelId/chapters/$chapterId")
        if (!chapterDir.exists()) return@withContext emptyList()

        val files = chapterDir.listFiles()?.filter { ArchiveExtractor.isImageFile(it.name) } ?: emptyList()
        val sorted = files.sortedWith { a, b -> NaturalOrderComparator().compare(a.name, b.name) }

        sorted.mapIndexed { index, file ->
            NovelPage(
                chapterId = chapterId,
                pageNumber = index + 1,
                globalPageNumber = priorPagesCount + index + 1,
                chapterTitle = chapterTitle,
                chapterIndex = chapterIndex,
                absoluteFilePath = file.absolutePath,
                fileName = file.name
            )
        }
    }

    suspend fun getAllNovelPages(novelId: String): List<NovelPage> = withContext(Dispatchers.IO) {
        val chapters = getChapters(novelId)
        val allPages = mutableListOf<NovelPage>()
        var globalIndex = 0

        chapters.forEach { chapter ->
            val chapterDir = File(baseNovelsDir, "$novelId/chapters/${chapter.id}")
            if (chapterDir.exists()) {
                val files = chapterDir.listFiles()?.filter { ArchiveExtractor.isImageFile(it.name) } ?: emptyList()
                val sorted = files.sortedWith { a, b -> NaturalOrderComparator().compare(a.name, b.name) }
                sorted.forEachIndexed { pageIdx, file ->
                    globalIndex++
                    allPages.add(
                        NovelPage(
                            chapterId = chapter.id,
                            pageNumber = pageIdx + 1,
                            globalPageNumber = globalIndex,
                            chapterTitle = chapter.title,
                            chapterIndex = chapter.chapterIndex,
                            absoluteFilePath = file.absolutePath,
                            fileName = file.name
                        )
                    )
                }
            }
        }
        allPages
    }

    suspend fun createMergedNovel(
        title: String,
        description: String,
        pendingChapters: List<PendingArchiveItem>,
        maxDimension: Int = 1080,
        onProgress: (Float, String) -> Unit
    ): NovelWork = withContext(Dispatchers.IO) {
        val novelId = "novel_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().take(6)
        val novelDir = File(baseNovelsDir, novelId).apply { mkdirs() }
        val chaptersDir = File(novelDir, "chapters").apply { mkdirs() }

        val chapterNamesMap = JSONObject()
        var totalPages = 0
        var firstCoverImage: File? = null

        val totalChapters = pendingChapters.size
        pendingChapters.forEachIndexed { index, item ->
            val chapterDirName = String.format("chapter_%03d", index + 1)
            val targetChapterDir = File(chaptersDir, chapterDirName)

            val percent = (index.toFloat() / totalChapters.toFloat()) * 0.9f
            val optMsg = if (maxDimension > 0) " (1080p optimize ediliyor)" else ""
            onProgress(percent, "${item.customChapterTitle} hazırlanıyor$optMsg... (${index + 1}/$totalChapters)")

            val extractedPages = ArchiveExtractor.extractChapterArchive(
                context = context,
                archiveUri = item.uri,
                archiveFileName = item.fileName,
                targetChapterDir = targetChapterDir,
                tempDir = tempDir,
                maxDimension = maxDimension,
                quality = 82
            )

            totalPages += extractedPages.size
            if (firstCoverImage == null && extractedPages.isNotEmpty()) {
                firstCoverImage = extractedPages.first()
            }

            chapterNamesMap.put(chapterDirName, item.customChapterTitle.ifBlank { "Bölüm ${index + 1}" })
        }

        onProgress(0.95f, "Kapak ve metaveriler oluşturuluyor...")

        // Save custom chapter names map
        File(novelDir, "chapter_names.json").writeText(chapterNamesMap.toString())

        // Create novel cover
        var coverPath: String? = null
        if (firstCoverImage != null && firstCoverImage!!.exists()) {
            val coverFile = File(novelDir, "cover.jpg")
            firstCoverImage!!.copyTo(coverFile, overwrite = true)
            coverPath = coverFile.absolutePath
        }

        val firstChapterId = if (totalChapters > 0) String.format("chapter_%03d", 1) else null

        val novelWork = NovelWork(
            id = novelId,
            title = title.ifBlank { "Birleştirilmiş Görsel Roman" },
            description = description.ifBlank { "$totalChapters bölüm tek parçaya birleştirildi." },
            coverPath = coverPath,
            chapterCount = totalChapters,
            pageCount = totalPages,
            lastReadChapterId = firstChapterId,
            lastReadPageIndex = 0,
            totalStorageBytes = calculateFolderSize(novelDir),
            createdAt = System.currentTimeMillis(),
            lastReadAt = System.currentTimeMillis()
        )

        saveNovelMetadata(novelWork)
        onProgress(1.0f, "Tamamlandı!")
        refreshNovelsList()
        novelWork
    }

    suspend fun saveReadingProgress(novelId: String, chapterId: String, pageIndex: Int) = withContext(Dispatchers.IO) {
        val currentList = _novels.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == novelId }
        if (index != -1) {
            val updated = currentList[index].copy(
                lastReadChapterId = chapterId,
                lastReadPageIndex = pageIndex,
                lastReadAt = System.currentTimeMillis()
            )
            currentList[index] = updated
            saveNovelMetadata(updated)
            _novels.value = currentList
        }
    }

    suspend fun toggleFavorite(novelId: String) = withContext(Dispatchers.IO) {
        val currentList = _novels.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == novelId }
        if (index != -1) {
            val updated = currentList[index].copy(isFavorite = !currentList[index].isFavorite)
            currentList[index] = updated
            saveNovelMetadata(updated)
            refreshNovelsList()
        }
    }

    suspend fun renameNovel(novelId: String, newTitle: String) = withContext(Dispatchers.IO) {
        val currentList = _novels.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == novelId }
        if (index != -1) {
            val updated = currentList[index].copy(title = newTitle.trim())
            currentList[index] = updated
            saveNovelMetadata(updated)
            refreshNovelsList()
        }
    }

    suspend fun deleteNovel(novelId: String) = withContext(Dispatchers.IO) {
        val folder = File(baseNovelsDir, novelId)
        if (folder.exists()) {
            folder.deleteRecursively()
        }
        refreshNovelsList()
    }

    suspend fun exportNovelToStream(novelId: String, outputStream: OutputStream) = withContext(Dispatchers.IO) {
        val folder = File(baseNovelsDir, novelId)
        if (folder.exists()) {
            ArchiveExtractor.exportNovelAsUnifiedCbz(folder, outputStream)
        }
    }

    fun updateReaderSettings(settings: ReaderSettings) {
        _readerSettings.value = settings
    }

    private fun calculateFolderSize(dir: File): Long {
        if (!dir.exists()) return 0L
        var size = 0L
        dir.walkTopDown().forEach { file ->
            if (file.isFile) {
                size += file.length()
            }
        }
        return size
    }
}
