package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import com.example.ui.components.DivineSunBackground
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Chapter
import com.example.model.NovelWork
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NovelAccentGold
import com.example.ui.theme.NovelPrimary
import com.example.ui.theme.NovelSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.viewmodel.AppScreen
import com.example.viewmodel.NovelViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterListScreen(viewModel: NovelViewModel) {
    val context = LocalContext.current
    val novel by viewModel.selectedNovel.collectAsState()
    val chapters by viewModel.chapters.collectAsState()

    BackHandler {
        viewModel.navigateTo(AppScreen.LIBRARY)
    }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null && novel != null) {
            context.contentResolver.openOutputStream(uri)?.use { stream ->
                viewModel.exportNovel(novel!!.id, stream)
            }
        }
    }

    if (novel == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("Görsel roman bulunamadı", color = TextPrimaryDark)
        }
        return
    }

    val currentNovel = novel!!

    DivineSunBackground(
        alpha = 0.85f,
        sunCenterBiasY = 0.20f
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DarkSurface.copy(alpha = 0.85f),
                        titleContentColor = TextPrimaryDark
                    ),
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppScreen.LIBRARY) },
                        modifier = Modifier.testTag("btn_back_chapter_list")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri", tint = TextPrimaryDark)
                    }
                },
                title = {
                    Text(
                        text = currentNovel.title,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleFavorite(currentNovel.id) }) {
                        Icon(
                            if (currentNovel.isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Favori",
                            tint = if (currentNovel.isFavorite) NovelAccentGold else TextPrimaryDark
                        )
                    }
                    IconButton(
                        onClick = {
                            exportLauncher.launch("${currentNovel.title.replace(" ", "_")}_Unified.cbz")
                        },
                        modifier = Modifier.testTag("btn_export_cbz")
                    ) {
                        Icon(Icons.Default.FolderZip, contentDescription = "Tek Parça CBZ İndir", tint = NovelSecondary)
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header Novel Banner & Resume Card
            item {
                NovelDetailHeaderCard(
                    novel = currentNovel,
                    onStartReading = {
                        viewModel.startReading(
                            novelId = currentNovel.id,
                            chapterId = currentNovel.lastReadChapterId ?: chapters.firstOrNull()?.id,
                            initialPageIndex = currentNovel.lastReadPageIndex
                        )
                    },
                    onExport = {
                        exportLauncher.launch("${currentNovel.title.replace(" ", "_")}_Unified.cbz")
                    }
                )
            }

            // Chapters List Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Birleştirilmiş Bölümler (${chapters.size})",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )
                    Text(
                        text = "Sırayla Okuyun",
                        fontSize = 12.sp,
                        color = NovelPrimary
                    )
                }
            }

            // Chapter items with global sequential page ranges
            var cumulativePages = 0
            val chapterRanges = chapters.map { ch ->
                val start = cumulativePages + 1
                val end = cumulativePages + ch.pageCount
                cumulativePages = end
                Pair(start, end)
            }

            items(chapters.indices.toList(), key = { chapters[it].id }) { idx ->
                val chapter = chapters[idx]
                val range = chapterRanges[idx]
                val isCurrentChapter = chapter.id == currentNovel.lastReadChapterId
                ChapterItemCard(
                    chapter = chapter,
                    startPage = range.first,
                    endPage = range.second,
                    isCurrent = isCurrentChapter,
                    onClick = {
                        viewModel.startReading(
                            novelId = currentNovel.id,
                            chapterId = chapter.id,
                            initialPageIndex = if (isCurrentChapter) currentNovel.lastReadPageIndex else 0
                        )
                    }
                )
            }
        }
    }
}
}

@Composable
fun NovelDetailHeaderCard(
    novel: NovelWork,
    onStartReading: () -> Unit,
    onExport: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                // Cover
                Box(
                    modifier = Modifier
                        .size(width = 96.dp, height = 136.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurfaceElevated)
                ) {
                    if (novel.coverPath != null && File(novel.coverPath).exists()) {
                        AsyncImage(
                            model = File(novel.coverPath),
                            contentDescription = novel.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Metadata Details
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = novel.title,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${novel.chapterCount} Bölüm • Toplam ${novel.pageCount} Sayfa",
                        fontSize = 13.sp,
                        color = NovelAccentGold,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = formatStorageSize(novel.totalStorageBytes),
                        fontSize = 11.sp,
                        color = TextSecondaryDark
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    // Reading progress
                    LinearProgressIndicator(
                        progress = { novel.progressPercent },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape),
                        color = NovelPrimary,
                        trackColor = DarkSurfaceElevated
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (novel.lastReadPageIndex > 0)
                            "Kaldığınız Sayfa: ${novel.lastReadPageIndex + 1} / ${novel.pageCount}"
                        else "Henüz başlanmadı",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                color = NovelPrimary.copy(alpha = 0.15f),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NovelPrimary.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "✓ Tüm ${novel.chapterCount} bölüm tek bir kitaba dönüştürüldü. Hiçbir butona basmadan baştan sona kesintisiz okuyabilirsiniz.",
                    color = NovelAccentGold,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons
            Row(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = onStartReading,
                    colors = ButtonDefaults.buttonColors(containerColor = NovelPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1.3f)
                        .height(44.dp)
                        .testTag("btn_resume_reading")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (novel.lastReadPageIndex > 0) "Kaldığın Sayfadan Oku (#${novel.lastReadPageIndex + 1})" else "Tek Kitap Olarak Oku",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                OutlinedButton(
                    onClick = onExport,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimaryDark),
                    modifier = Modifier
                        .weight(0.9f)
                        .height(44.dp)
                        .testTag("btn_export_unified_cbz")
                ) {
                    Icon(
                        Icons.Default.FolderZip,
                        contentDescription = null,
                        tint = NovelSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "CBZ İndir",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
fun ChapterItemCard(
    chapter: Chapter,
    startPage: Int,
    endPage: Int,
    isCurrent: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .border(
                1.dp,
                if (isCurrent) NovelPrimary else DarkSurfaceBorder,
                RoundedCornerShape(12.dp)
            )
            .testTag("chapter_item_${chapter.chapterIndex}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrent) NovelPrimary.copy(alpha = 0.12f) else DarkSurface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Chapter thumbnail or badge
            Box(
                modifier = Modifier
                    .size(width = 54.dp, height = 70.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurfaceElevated)
            ) {
                if (chapter.thumbnailPath != null && File(chapter.thumbnailPath).exists()) {
                    AsyncImage(
                        model = File(chapter.thumbnailPath),
                        contentDescription = chapter.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "#${chapter.chapterIndex}",
                            fontWeight = FontWeight.Bold,
                            color = NovelPrimary,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Title & Info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = chapter.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isCurrent) NovelPrimary else TextPrimaryDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${chapter.pageCount} Sayfa • Sıralı: $startPage - $endPage. Görseller",
                    fontSize = 12.sp,
                    color = NovelAccentGold
                )
            }

            if (isCurrent) {
                Surface(
                    color = NovelPrimary,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.padding(end = 6.dp)
                ) {
                    Text(
                        text = "Okunuyor",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Icon(
                Icons.Default.PlayArrow,
                contentDescription = "Bölümü Oku",
                tint = if (isCurrent) NovelPrimary else TextSecondaryDark,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

private fun formatStorageSize(bytes: Long): String {
    if (bytes <= 0) return "0 KB"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format("%.1f GB", gb)
        mb >= 1.0 -> String.format("%.1f MB", mb)
        else -> String.format("%.0f KB", kb)
    }
}
